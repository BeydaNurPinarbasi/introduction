﻿using System;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Yaşınızı giriniz:");
            int age = int.Parse (Console.ReadLine());
            if (age >= 18)
            {
                Console.WriteLine("Araba Ehliyeti Alabilir ");
                    }
            if (age < 18)
            {
                Console.WriteLine("Araba Ehliyeti Alamaz ");

            }
            if (age >= 23)
            {
                Console.WriteLine("D sınıfı ehliyet alabilir.");
            }

            Console.WriteLine("----------------------");

            // geliştirmek için notlar diploma denkliği kontrolü yapılabilir 





        }
    }
}
