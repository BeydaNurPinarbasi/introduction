﻿using System;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Beyda'nın Çalışma Defteri ");
            Console.WriteLine("Girdiğiniz sayının pozitif mi negatif mi olduğu öğrenme");
            Console.Write("Sayı Giriniz ");
            int sayi=int.Parse(Console.ReadLine());
            
            if (sayi > 0)
            {
                Console.WriteLine("Sayı Pozitiftir.");
            }
            else if (sayi < 0)
            {
                Console.WriteLine("Sayı Negatiftir.");
            }
            else if (sayi == 0)
            {
                Console.WriteLine("Sayı Nötrdür.");
            }
            
           





        }
    }
}
