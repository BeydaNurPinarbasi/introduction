﻿using System;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            string mesaj = " Beyda'nın Çalışma Defteri ";

            Console.WriteLine(mesaj);

            Console.WriteLine("çarpma işlemi konsol uygulama da nasıl yapılır kaynak koduna bak  ");
            int sayi = 6;
            double d = 48.15;
            double işlem = (sayi * d);
            Console.WriteLine(işlem);


            string ad = "Beyda Nur";
            string soyad = "Pınarbaşı";
            Console.WriteLine(ad+ " "+ soyad+" ");


            int yil = 2024;
            int dogumyili = 1999;
            int yas = yil - dogumyili;
            Console.WriteLine("Yas: "+ yas);


        }
    }
}
